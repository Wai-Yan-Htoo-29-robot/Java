## PJ environment setting up

#### 1. Setup database

1) Install postgresSQL 
https://www.enterprisedb.com/downloads/postgres-postgresql-downloads

2) Install PgAdmin4 
https://www.postgresql.org/ftp/pgadmin/pgadmin4/v6.18/windows/

3) Create database
See pictures at db_setup.

#### 2. Maven build
Get packages for local project repository
Maven version is 3.8 or above
-----
mvn clean package
-----

Expected result
[INFO] Replacing main artifact with repackaged archive
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time:  20.953 s
[INFO] Finished at: 2023-01-08T22:54:02+06:30
[INFO] ------------------------------------------------------------------------

#### 3. Run Project in eclipse
Run > SpringBootProject

------

  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::                (v2.7.0)

2023-01-09 19:04:03.051  INFO 24228 --- [           main] com.acromyanmar.springboot.Initializer   : Starting Initializer using Java 17.0.4.1 on AcroMyanmar71pc with PID 24228 (C:\AcroWorks\work\NewStaffTraining\Assignment\10_JavaWebApplication\baseapp\BookManagement\BookManagement\target\classes started by thinpyai in C:\AcroWorks\work\NewStaffTraining\Assignment\10_JavaWebApplication\baseapp\BookManagement\BookManagement)
2023-01-09 19:04:03.054  INFO 24228 --- [           main] com.acromyanmar.springboot.Initializer   : No active profile set, falling back to 1 default profile: "default"
2023-01-09 19:04:03.503  INFO 24228 --- [           main] .s.d.r.c.RepositoryConfigurationDelegate : Bootstrapping Spring Data JPA repositories in DEFAULT mode.
2023-01-09 19:04:03.518  INFO 24228 --- [           main] .s.d.r.c.RepositoryConfigurationDelegate : Finished Spring Data repository scanning in 5 ms. Found 0 JPA repository interfaces.
2023-01-09 19:04:03.882  INFO 24228 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat initialized with port(s): 8080 (http)
2023-01-09 19:04:03.889  INFO 24228 --- [           main] o.apache.catalina.core.StandardService   : Starting service [Tomcat]
2023-01-09 19:04:03.889  INFO 24228 --- [           main] org.apache.catalina.core.StandardEngine  : Starting Servlet engine: [Apache Tomcat/9.0.63]
2023-01-09 19:04:04.014  INFO 24228 --- [           main] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring embedded WebApplicationContext
2023-01-09 19:04:04.014  INFO 24228 --- [           main] w.s.c.ServletWebServerApplicationContext : Root WebApplicationContext: initialization completed in 925 ms
2023-01-09 19:04:04.133  INFO 24228 --- [           main] com.zaxxer.hikari.HikariDataSource       : HikariPool-1 - Starting...
2023-01-09 19:04:04.302  INFO 24228 --- [           main] com.zaxxer.hikari.HikariDataSource       : HikariPool-1 - Start completed.
2023-01-09 19:04:04.336  INFO 24228 --- [           main] o.hibernate.jpa.internal.util.LogHelper  : HHH000204: Processing PersistenceUnitInfo [name: default]
2023-01-09 19:04:04.368  INFO 24228 --- [           main] org.hibernate.Version                    : HHH000412: Hibernate ORM core version 5.6.9.Final
2023-01-09 19:04:04.485  INFO 24228 --- [           main] o.hibernate.annotations.common.Version   : HCANN000001: Hibernate Commons Annotations {5.1.2.Final}
2023-01-09 19:04:04.578  INFO 24228 --- [           main] org.hibernate.dialect.Dialect            : HHH000400: Using dialect: org.hibernate.dialect.PostgreSQL10Dialect
2023-01-09 19:04:04.945  INFO 24228 --- [           main] o.h.e.t.j.p.i.JtaPlatformInitiator       : HHH000490: Using JtaPlatform implementation: [org.hibernate.engine.transaction.jta.platform.internal.NoJtaPlatform]
2023-01-09 19:04:04.952  INFO 24228 --- [           main] j.LocalContainerEntityManagerFactoryBean : Initialized JPA EntityManagerFactory for persistence unit 'default'
2023-01-09 19:04:05.174  WARN 24228 --- [           main] JpaBaseConfiguration$JpaWebConfiguration : spring.jpa.open-in-view is enabled by default. Therefore, database queries may be performed during view rendering. Explicitly configure spring.jpa.open-in-view to disable this warning
2023-01-09 19:04:05.452  INFO 24228 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8080 (http) with context path ''
2023-01-09 19:04:05.460  INFO 24228 --- [           main] com.acromyanmar.springboot.Initializer   : Started Initializer in 2.675 seconds (JVM running for 3.314)
2023-01-09 19:04:10.520  INFO 24228 --- [nio-8080-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring DispatcherServlet 'dispatcherServlet'
2023-01-09 19:04:10.520  INFO 24228 --- [nio-8080-exec-1] o.s.web.servlet.DispatcherServlet        : Initializing Servlet 'dispatcherServlet'
2023-01-09 19:04:10.521  INFO 24228 --- [nio-8080-exec-1] o.s.web.servlet.DispatcherServlet        : Completed initialization in 1 ms
2023-01-09 19:04:10.618  INFO 24228 --- [nio-8080-exec-1] c.a.s.controller.BookController          : Success
2023-01-09 19:04:17.443  INFO 24228 --- [nio-8080-exec-3] c.a.s.controller.BookController          : Success

#### 4. API call 

http://localhost:8080/books/
