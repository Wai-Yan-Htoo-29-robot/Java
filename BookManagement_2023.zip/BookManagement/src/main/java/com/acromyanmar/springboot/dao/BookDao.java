package com.acromyanmar.springboot.dao;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.acromyanmar.springboot.entity.Book;
//import org.springframework.data.repository.CrudRepository;
/**
 * this is a BookDao interface for book
 * @author AcroMyanmar
 *
 */
//@Component
@Repository
public interface BookDao //extends CrudRepository<Book, Long>
{
    /**
     * Get bookList
     * @return List<Book> is a data of book
     */
    List<Book> getAllBookList();
}
