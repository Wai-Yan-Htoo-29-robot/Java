package com.acromyanmar.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * this is Initializer class
 * @author AcroMyanmar
 *
 */
@Configuration
@SpringBootApplication
@ComponentScan("com.acromyanmar.springboot")
@EnableAutoConfiguration
public class Initializer 
{
    /**
     * Initializer Constructor
     */
    public Initializer()
    {

    }

    /**
    * main method and run Initializer class
    * @param args String arrays
    */
    public static void main(String[] args)
    {
        SpringApplication.run(Initializer.class, args);
    }

}
