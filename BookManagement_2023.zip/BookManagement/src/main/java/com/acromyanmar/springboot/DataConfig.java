package com.acromyanmar.springboot;

import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * this is dataConfig class
 * @author AcroMyanmar
 *
 */
@Configuration
//@EnableTransactionManagement
@MapperScan("com.acromyanmar.springboot.dao")
public class DataConfig
{
    /**
     * DataConfig controller
     */
    public DataConfig()

    {

    }

    /**
     * 
     * @param dataSource object
     * @return factory
     */
    @Bean
    public SqlSessionFactoryBean sqlSessionFactoryBean(DataSource dataSource)
    {
        SqlSessionFactoryBean factory = new SqlSessionFactoryBean();
        factory.setDataSource(dataSource);
        factory.setConfigLocation(new ClassPathResource("/mybatis-config.xml"));
        return factory;
    }

    /**
     * 
     * @param dataSource object
     * @return dataTransactionManager
     */
//    @Bean
////    @Autowired
//    protected PlatformTransactionManager createTransactionManager(
//            DataSource dataSource)
//    {
//        DataSourceTransactionManager dataTransactionManager = new DataSourceTransactionManager(
//                dataSource);
//        return dataTransactionManager;
//    }
}
