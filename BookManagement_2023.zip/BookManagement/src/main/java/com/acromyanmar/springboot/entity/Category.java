package com.acromyanmar.springboot.entity;

import javax.persistence.Id;

/**
 * this is category class
 * @author AcroMyanmar
 *
 */
public class Category
{
    /**
     * declare categoryId
     */
    @Id
    public int    categoryId;

    /**
     * declare categoryName
     */
    public String categoryName;

    /**
     * declare constructor with arguments
     * @param categoryId category id
     * @param categoryName category name
     */
    public Category(int categoryId, String categoryName)
    {
        super();
        this.categoryId = categoryId;
        this.categoryName = categoryName;
    }

    /**
     * declare constructor
     */
    public Category()
    {
        super();

    }

    /**
     * this method is to get categoryId from database
     * @return categoryId
     */
    public int getCategoryId()
    {
        return categoryId;
    }

    /**
     * this method is to set categoryId 
     * @param categoryId category id
     */
    public void setCategoryId(int categoryId)
    {
        this.categoryId = categoryId;
    }

    /**
     * this method is to get categoryName from database
     * @return categoryName
     */
    public String getCategoryName()
    {
        return categoryName;
    }

    /**
     * this method is to set categoryName 
     * @param categoryName category name
     */
    public void setCategoryName(String categoryName)
    {
        this.categoryName = categoryName;
    }
}
