package com.acromyanmar.springboot.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * this is book class
 * @author AcroMyanmar
 *
 */
@Entity
public class Book
{

    /**
     * declare book_id
     */
    @Id
    public int    bookId;

    /**
     * declare titleOfBook
     */
    public String titleOfBook;

    /**
     * declare author
     */
    public String author;

    /**
     * declare publisher
     */
    public String publisher;

    /**
     * declare categoryId
     */
    public int    categoryId;

    /**
     * declare returnScheduleDate
     */
    public String returnScheduleDate;

    /**
     * declare outline
     */
    public String outline;

    /**
     * declare constructor
     */
    public Book()
    {
        super();

    }

    /**
     * declare constructor with arguments
     * @param bookid book id
     * @param titleOfBook title of book
     * @param author author
     * @param publisher publisher
     * @param categoryid category id
     * @param returnScheduleDate return schedule date
     * @param outline outline
     */
    public Book(int bookid, String titleOfBook, String author, String publisher,
            int categoryid, String returnScheduleDate, String outline)
    {
        super();
        this.bookId = bookid;
        this.titleOfBook = titleOfBook;
        this.author = author;
        this.publisher = publisher;
        this.categoryId = categoryid;
        this.returnScheduleDate = returnScheduleDate;
        this.outline = outline;

    }

    /**
     * this method is to get book id from database
     * @return bookId bookId
     */
    public int getBookId()
    {
        return bookId;
    }

    /**
     * this method is to set book id 
     * @param bookId book id
     */
    public void setBookId(int bookId)
    {
        this.bookId = bookId;
    }

    /**
     * this method is to get title of book from database
     * @return titleOfBook
     */
    public String getTitleOfBook()
    {

        return titleOfBook;
    }

    /**
     * this method is to set tile of book
     * @param titleOfBook title of book
     */
    public void setTitleOfBook(String titleOfBook)
    {
        this.titleOfBook = titleOfBook;
    }

    /**
     * this method is to get author from database
     * @return author
     */
    public String getAuthor()
    {
        return author;
    }

    /**
     * this method is to set author
     * @param author author
     */
    public void setAuthor(String author)
    {
        this.author = author;
    }

    /**
     * this method is to get publisher from database
     * @return publisher
     */
    public String getPublisher()
    {
        return publisher;
    }

    /**
     * this method is to set publisher 
     * @param publisher publisher
     */
    public void setPublisher(String publisher)
    {
        this.publisher = publisher;
    }

    /**
     * this method is to get category id from database
     * @return categoryId categoryId
     */
    public int getCategoryId()
    {
        return categoryId;
    }

    /**
     * this method is to set category id 
     * @param categoryId category id
     */
    public void setCategoryId(int categoryId)
    {
        this.categoryId = categoryId;
    }

    /**
     * this method is to get returnScheduleDate from database
     * @return returnScheduelDate return Schedule Date
     */
    public String getReturnScheduleDate()
    {
        return returnScheduleDate;
    }

    /**
     * this method is to set returnScheduleDate 
     * @param returnScheduleDate return schedule date
     */
    public void setReturnScheduleDate(String returnScheduleDate)
    {
        this.returnScheduleDate = returnScheduleDate;
    }

    /**
     * this method is to get outline from database
     * @return outline
     */
    public String getOutline()
    {
        return outline;
    }

    /**
     * this method is to set outline 
     * @param outline outline
     */
    public void setOutline(String outline)
    {
        this.outline = outline;
    }

}
