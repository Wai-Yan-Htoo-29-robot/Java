package com.acromyanmar.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.acromyanmar.springboot.dao.BookDao;
import com.acromyanmar.springboot.entity.Book;

/**
 * this is BookService class for book
 * @author AcroMyanmar
 *
 */
@Service
public class BookService
{
    /**
     *  dao is variable for creation of object bookDao.
     */
    @Autowired
    BookDao bookDao_;

    /**
     * default constructor
     */
    public BookService()
    {
        //do nothing
    }

    /**
     * Get bookList from database
     * @return List<Book> data of book
     */
    public List<Book> getAllBookList()
    {
        return this.bookDao_.getAllBookList();
    }

}
