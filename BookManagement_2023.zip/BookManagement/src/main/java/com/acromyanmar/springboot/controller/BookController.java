package com.acromyanmar.springboot.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.acromyanmar.springboot.service.BookService;

/**
 * this is RegisteredUserListController class
 * @author AcroMyanmar
 *
 */
@Controller
@RequestMapping("/books")
public class BookController
{
    /**
     * declare logger
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(
            BookController.class);

    /**
     * declare service for book
     */
    @Autowired
    BookService                 bookService_;

    /**
     * declare constructor
     */
    public BookController()
    {
        // do nothing
    }

    /**
     * this method is used to get the bookList
     * @param model model
     * @return bookList book list
     */
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String home(Model model)
    {

        model.addAttribute("bookList",this.bookService_.getAllBookList() );
        LOGGER.info("Success");
        return "BookList";
    }

}
