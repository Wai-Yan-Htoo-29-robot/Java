package com.acromyanmar.springboot.dao;

/**
 * this is a CategoryDao interface for category
 * @author AcroMyanmar
 *
 */
public interface CategoryDao
{

}
