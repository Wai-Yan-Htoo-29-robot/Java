package com.acromyanmar.springboot.service;

import org.springframework.stereotype.Service;

/**
 * this is CategoryService class for category
 * @author AcroMyanmar
 *
 */
@Service
public class CategoryService
{
    /**
     * default constructor
     */
    public CategoryService()
    {
        //do nothing
    }

}
