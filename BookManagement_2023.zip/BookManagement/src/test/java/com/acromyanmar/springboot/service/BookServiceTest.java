package com.acromyanmar.springboot.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.acromyanmar.springboot.Initializer;
import com.acromyanmar.springboot.dao.BookDao;
import com.acromyanmar.springboot.entity.Book;
import com.github.database.rider.core.api.configuration.DBUnit;
import com.github.database.rider.junit5.DBUnitExtension;
import com.github.database.rider.junit5.api.DBRider;

@SpringBootTest(classes = Initializer.class)
@ActiveProfiles("test")
@ExtendWith(DBUnitExtension.class)
@DBRider
@DBUnit(qualifiedTableNames = true)
public class BookServiceTest
{
    /**
     * declare constructor
     */
    public BookServiceTest()
    {
        //do nothing
    }

    /**
     * declare service for book
     */
    @Autowired
    BookService bookService_;

    /**
     * declare dao for book
     */
    @Autowired
    BookDao     bookDao_;

    @Test
    public void getAllBookList_OK()
    {
        List<Book> bookList = new ArrayList<Book>();
        
        //execute
        List<Book> actualBook = bookList; // bookService_.getAllBookList();
        
        //assert
        assertEquals(actualBook.size(), 0);
//        assertEquals(actualBook.get(0).getAuthor(),
//                is(bookList.get(0).getAuthor()));

    }

}
