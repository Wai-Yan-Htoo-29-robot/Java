insert into book(title_of_book, author, publisher, category_id, return_schedule_date, outline) values 
('Easy Java', 'ManaTakahashi', 'Softbank Creative', 1, '2019-12-31', 'For basic knowledge of java.  It is better to study Java for the first time.'),
('Effective Java', 'Joshua Bloch', 'Pearson Education', 1, '2020-01-15', 'Java technique book for inter mediate class.'),
('Technique for writing good code', 'Toshitaka Agata', 'gihyo', 1, '2020-01-03', 'Beginners and intermediate can read.  You can write coding which is easy to read for other people.');

insert into category(category_id, category_name) values
(1, 'IT'),
(2, 'novel'),
(3, 'documentary');
