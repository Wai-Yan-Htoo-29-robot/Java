-- Table: public.book

-- DROP TABLE public.book;

CREATE TABLE public.book
(
    id SERIAL NOT NULL,
    title_of_book character varying(256) COLLATE pg_catalog."default",
    author character varying(256) COLLATE pg_catalog."default",
    publisher character varying(256) COLLATE pg_catalog."default",
    category_id integer,
    return_schedule_date date,
    outline character varying(1024) COLLATE pg_catalog."default"
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.book
    OWNER to bookmanagement;


-- Table: public.category

-- DROP TABLE public.category;

CREATE TABLE public.category
(
    category_id SERIAL NOT NULL,
    category_name character varying(128) COLLATE pg_catalog."default",
    CONSTRAINT category_pkey PRIMARY KEY (category_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.category
    OWNER to bookmanagement;

